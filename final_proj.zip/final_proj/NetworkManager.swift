//
//  NetworkManager.swift
//  final_proj
//
//  Created by Kevin Arias on 5/5/22.
//

import Foundation
import Alamofire

class NetworkManager {
    static let host = "http://34.124.115.253"
    
    static func getAllUsers(completion: @escaping ([User]) -> Void) {
        let endpoint = "\(host)/api/users/"

        AF.request(endpoint, method: .get).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                if let userResponse = try? jsonDecoder.decode([User].self, from: data) {
                    completion(userResponse)
                } else {
                    print("Failed to getAllUsers")
                }
            
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func getSpecificUser(id: String, completion: @escaping (User) -> Void) {
        let endpoint = "\(host)/api/users/\(id)/"
        
        AF.request(endpoint, method: .get).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(User.self, from: data) {
                    completion(userResponse)
                } else {
                    print("Failed to getSpecificUser")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func createUser(name: String, username: String, password: String, completion: @escaping (User) -> Void) {
        let endpoint = "\(host)/api/users/"
        let params: [String: String] = [
            "name": name,
            "username": username,
            "password": password
        ]

        AF.request(endpoint, method: .post, parameters: params).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(User.self, from: data) {
                    completion(userResponse)
                } else {
                    print("Failed to createUser")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func getUserByPassword(username: String, password: String, completion: @escaping (User) -> Void) {
        let endpoint = "\(host)/api/users/login"
        let params: [String: String] = [
            "username": username,
            "password": password
        ]

        AF.request(endpoint, method: .post, parameters: params).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(User.self, from: data) {
                    completion(userResponse)
                } else {
                    print("Failed to getUserByPassword")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func addEventUser(id: String, event_id: String, event_type: String, completion: @escaping (User) -> Void) {
        let endpoint = "\(host)/api/users/\(id)/add_event/"
        let params: [String: String] = [
            "event_id": event_id,
            "event_type": event_type
        ]
        
        AF.request(endpoint, method: .post, parameters: params).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(User.self, from: data) {
                    completion(userResponse)
                } else {
                    print("Failed to addEventUser")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func editUsername(id: String, username: String, completion: @escaping (User) -> Void) {
        let endpoint = "\(host)/api/users/\(id)/"
        let params: [String: String] = [
            "id": id,
            "username": username
        ]
        
        AF.request(endpoint, method: .put, parameters: params).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(User.self, from: data) {
                    completion(userResponse)
                } else {
                    print("Failed to editUsername")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func deleteUser(id: String, username: String, password: String, completion: @escaping (User) -> Void) {
        let endpoint = "\(host)/api/users/\(id)/"
        let params: [String: String] = [
            "id": id,
            "username": username,
            "password": password
        ]

        AF.request(endpoint, method: .delete, parameters: params, encoder: JSONParameterEncoder.default).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(User.self, from: data) {
                    completion(userResponse)
                } else {
                    print("Failed to deleteUser")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func getAllMovies(completion: @escaping ([Movie]) -> Void) {
        let endpoint = "\(host)/api/movies/"

        AF.request(endpoint, method: .get).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                if let userResponse = try? jsonDecoder.decode([Movie].self, from: data) {
                    completion(userResponse)
                } else {
                    print("Failed to getAllMovies")
                }
            
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }

    static func getSpecificMovie(id: String, completion: @escaping (Movie) -> Void) {
        let endpoint = "\(host)/api/movies/\(id)/"
        
        AF.request(endpoint, method: .get).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(Movie.self, from: data) {
                    completion(userResponse)
                } else {
                    print("Failed to getSpecificMovie")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func createMovie(name: String, description: String, completion: @escaping (Movie) -> Void) {
        let endpoint = "\(host)/api/movies/"
        let params: [String: String] = [
            "name": name,
            "description": description
        ]

        AF.request(endpoint, method: .post, parameters: params).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(Movie.self, from: data) {
                    completion(userResponse)
                } else {
                    print("Failed to createMovie")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func getAllEvents(completion: @escaping ([Event]) -> Void) {
        let endpoint = "\(host)/api/events/"

        AF.request(endpoint, method: .get).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                if let userResponse = try? jsonDecoder.decode([Event].self, from: data) {
                    completion(userResponse)
                } else {
                    print("Failed to getAllEvents")
                }
            
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    static func createEvent(name: String, location: String, start: String, end: String, completion: @escaping (Event) -> Void) {
        let endpoint = "\(host)/api/events/"
        let params: [String: String?] = [
            "name": name,
            "location": location,
            "start": start,
            "end": end,
        ]

        AF.request(endpoint, method: .post, parameters: params).validate().responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                jsonDecoder.dateDecodingStrategy = .iso8601
                if let userResponse = try? jsonDecoder.decode(Event.self, from: data) {
                    completion(userResponse)
                } else {
                    print("Failed to createEvent")
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}
