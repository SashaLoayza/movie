//
//  EventInfoViewController.swift
//  final_proj
//
//  Created by Kevin Arias on 5/1/22.
//

import UIKit
import SwiftUI

class EventInfoViewController: UIViewController {
    var eventObject: Event?
    var currUser: User?
    let nameLabel = UILabel()
    let interestedBtn = UIButton()
    let eventInfoTextView = UITextView()
    
    let padding: CGFloat = 20
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .systemGray5
        setupViews()
        setupConstraints()
    }
    
    func setupViews() {

        // nameLabel setup
        nameLabel.text = eventObject?.name
        nameLabel.font = UIFont.boldSystemFont(ofSize: 30)
        nameLabel.textColor = .systemBlue
        nameLabel.textAlignment = .left
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nameLabel)
        
        // interestedBtn setup
        let checkmark = UIImage(systemName: "checkmark")
        interestedBtn.setImage(checkmark, for : .normal)
        interestedBtn.tintColor = .systemRed
        interestedBtn.layer.backgroundColor = UIColor.white.cgColor
        interestedBtn.frame = CGRect(x: 400, y: 400, width: 30, height: 30)
        interestedBtn.layer.cornerRadius = interestedBtn.frame.width / 2
        interestedBtn.addTarget(self, action: #selector(updateInterestedInEvent), for: .touchUpInside)
        interestedBtn.clipsToBounds = true
        interestedBtn.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(interestedBtn)
        
        
        // eventInfoTextView setup
        eventInfoTextView.text =
            "When: \((eventObject!.start!)) - \((eventObject!.end!))\n\n" +
            "Where: \((eventObject!.location!))\n\n"
//            "Organized by: \(eventObject!.host ?? "N/A")\n\n"
        eventInfoTextView.font = UIFont.systemFont(ofSize: 15)
        eventInfoTextView.backgroundColor = .white
        eventInfoTextView.isEditable = false
        eventInfoTextView.textContainerInset = UIEdgeInsets(top: padding, left: padding, bottom: padding, right: padding)
        eventInfoTextView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(eventInfoTextView)
    }

    func setupConstraints() {

        // nameLabel constraints
        NSLayoutConstraint.activate([
            nameLabel.bottomAnchor.constraint(equalTo: view.centerYAnchor, constant: -60),
            nameLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
            nameLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -100)
        ])
        
        // interestedBtn constraints
        NSLayoutConstraint.activate([
            interestedBtn.leadingAnchor.constraint(equalTo: nameLabel.trailingAnchor),
            interestedBtn.topAnchor.constraint(equalTo: nameLabel.topAnchor),
            interestedBtn.bottomAnchor.constraint(equalTo: nameLabel.bottomAnchor),
            interestedBtn.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding)
        ])
        
        // eventInfoTextView constraints
        NSLayoutConstraint.activate([
            eventInfoTextView.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 15),
            eventInfoTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            eventInfoTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            eventInfoTextView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
    }
    
    @objc func updateInterestedInEvent() {
        if interestedBtn.imageView?.tintColor == .systemRed {
            interestedBtn.imageView?.tintColor = .systemGreen
        } else if interestedBtn.imageView?.tintColor == .systemGreen {
            interestedBtn.imageView?.tintColor = .systemRed
        }
    }
    
    // initialize to have event and user available to display information
    init(eventObject: Event?, currUser: User?) {
        super.init(nibName: nil, bundle: nil)
        self.currUser = currUser
        self.eventObject = eventObject
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
