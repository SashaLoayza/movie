//
//  EventInfoViewController.swift
//  final_proj
//
//  Created by Kevin Arias on 5/1/22.
//

import UIKit

class EventInfoViewController: UIViewController {
    var eventObject: Event?
    let hostLabel = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .systemGray5
        setupViews()
        setupConstraints()
    }
    
    func setupViews() {
        // hostLabel setup
        hostLabel.text = "Hosted by: \(eventObject?.hostedBy ?? "N/A")"
        hostLabel.font = UIFont.systemFont(ofSize: 20)
        hostLabel.textAlignment = .center
        hostLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(hostLabel)
    }

    func setupConstraints() {
        let sidePadding: CGFloat = 20
        // hostLabel constraints
        NSLayoutConstraint.activate([
            hostLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 15),
            hostLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: sidePadding),
            hostLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: sidePadding)
        ])
    }
    
    // initialize to have event available to display information
    init(eventObject: Event?) {
        super.init(nibName: nil, bundle: nil)
        self.eventObject = eventObject
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
