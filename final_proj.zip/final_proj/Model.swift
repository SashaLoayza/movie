//
//  Model.swift
//  final_proj
//
//  Created by Kevin Arias on 5/1/22.
//

import UIKit

class Event: Codable {
    let id: String?
    let name: String?
    let location: String?
    let date: String?
    let start: String?
    let end: String?
    let hostedBy: String?
    
    init(id: String?, name: String?, location: String?, date: String?, start: String?, end: String?, hostedBy: String?) {

        self.id = id
        self.name = name
        self.location = location
        self.date = date
        self.start = start
        self.end = end
        self.hostedBy = hostedBy
    }
}

class User: Codable {
    let id: String?
    let username: String?
    let password: String?
    let moviesWatched: String?
    let eventsInterested: String?
    let moviesInterested: String?
    
    init(id: String?, username: String?, password: String?, moviesWatched: String?, eventsInterested: String?, moviesInterested: String?) {
        
        self.id = id
        self.username = username
        self.password = password
        self.moviesWatched = moviesWatched
        self.eventsInterested = eventsInterested
        self.moviesInterested = moviesInterested
    }
}

class Movie: Codable {
    let id: String?
    let name: String?
    let description: String?
    let rating: String?
    let reviews: String?
    let usersInterested: String?
    
    init(id: String?, name: String?, description: String?, rating: String?, reviews: String?, usersInterested: String?) {
        
        self.id = id
        self.name = name
        self.description = description
        self.rating = rating
        self.reviews = reviews
        self.usersInterested = usersInterested
    }
}

