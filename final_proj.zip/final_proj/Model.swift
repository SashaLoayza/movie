//
//  Model.swift
//  final_proj
//
//  Created by Kevin Arias on 5/1/22.
//

import UIKit

class Event: Codable {
    let id: String?
    let name: String?
    let location: String?
    let start: String?
    let end: String?
//    let host: String?
//    let users_interested: String?
    
    init(id: String?, name: String?, location: String?, start: String?, end: String?) {

        self.id = id
        self.name = name
        self.location = location
        self.start = start
        self.end = end
//        self.host = host
//        self.users_interested = users_interested
    }
}

class User: Codable {
    let id: String?
    let name: String?
    let username: String?
    let password: String?
    let movies_watched: String?
    let events_interested: String?
    let movies_interested: String?
    let movies_hosted: String?
    
    init(id: String?, name: String?, username: String?, password: String?, movies_watched: String?, events_interested: String?, movies_interested: String?, movies_hosted: String?) {
        
        self.id = id
        self.name = name
        self.username = username
        self.password = password
        self.movies_watched = movies_watched
        self.events_interested = events_interested
        self.movies_interested = movies_interested
        self.movies_hosted = movies_hosted
    }
}

class Movie: Codable {
    let id: String?
    let name: String?
    let description: String?
    let rating: String?
    let users_watched: String?
    let users_interested: String?
    
    init(id: String?, name: String?, description: String?, rating: String?, users_watched: String?, users_interested: String?) {
        
        self.id = id
        self.name = name
        self.description = description
        self.rating = rating
        self.users_watched = users_watched
        self.users_interested = users_interested
    }
}

