//
//  ProfileViewController.swift
//  final_proj
//
//  Created by Kevin Arias on 5/6/22.
//

import UIKit

class ProfileViewController: UIViewController {
    
    var currUser: User?
    let customBackButtonItem = UIBarButtonItem()
    let userImageBtn = UIButton()
    
    // initialize to have user available to display information
    init(currUser: User?) {
        super.init(nibName: nil, bundle: nil)
        self.currUser = currUser
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        title = "My Profile"
        view.backgroundColor = .systemGray5
        
        setupViews()
        setupConstraints()
    }
    
    func setupViews() {
        // customBackButtonItem setup
        customBackButtonItem.title = "< Back"
        customBackButtonItem.target = self
        customBackButtonItem.action = #selector(backBtnPress)
        navigationItem.leftBarButtonItem = customBackButtonItem
        navigationItem.leftBarButtonItem?.tintColor = .white
    }
    
    func setupConstraints() {
    }
    
    @objc func backBtnPress() {
        self.navigationController?.popViewController(animated: true)
    }
}
