//
//  ViewController.swift
//  final_proj
//
//  Created by Kevin Arias on 5/1/22.
//

import UIKit

class ViewController: UIViewController {
    
    let eventTableView = UITableView()
    let eventReuseIdentifier = "eventReuseIdentifier"
    let refreshControl = UIRefreshControl()
    let addEventBtn = UIBarButtonItem()
    
    // alert for adding event
    let createAlert = UIAlertController(title: "Add new event", message: nil, preferredStyle: .alert)
    
    var eventData: [Event] = []
    var shownEventData: [Event] = []
        
    var currentIndexPathToUpdate: IndexPath?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        title = "Upcoming Events"
        
        createDummyData() // WILL CHANGE THIS ONCE ROUTES CONFIGURED
        setupViews()
        setupConstraints()
        refreshData()
        
    }
    
    func createDummyData() {
        let event1 = Event(id: "1", name: "Movie", location: "Donlon", date: "June 4, 2032", start: "5:45PM", end: "2:45AM", hostedBy: "me obviously")
        let event2 = Event(id: "2", name: "Movie: The Sequel", location: "Also Donlon", date: "June 5, 1987", start: "3:45PM", end: "5:00PM", hostedBy: "also me")
        
        let events = [event1, event2]
        self.eventData = events
        // should sort here, by what Idk yet
        self.shownEventData = self.eventData
        self.eventTableView.reloadData()
    }
    
    func setupViews() {
        // eventTableView setup
        eventTableView.backgroundColor = .systemGray5
        eventTableView.delegate = self
        eventTableView.dataSource = self
        eventTableView.register(EventTableViewCell.self, forCellReuseIdentifier: eventReuseIdentifier)
        eventTableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(eventTableView)
        
        // addEventButton setup
        addEventBtn.image = UIImage(systemName: "plus")
        addEventBtn.target = self
        addEventBtn.action = #selector(presentCreateAlert)
        navigationItem.rightBarButtonItem = addEventBtn
        
        // createAlert setup
        createAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        let placeholderTexts = [
            "Name of event",
            "Date of event",
            "Start time",
            "End time",
            "Location of event",
            "Host of event"
        ]
        
        for placeholderText in placeholderTexts {
            createAlert.addTextField(configurationHandler: { textField in
                textField.placeholder = placeholderText
            })
        }
        
        createAlert.addAction(UIAlertAction(title: "Add", style: .default, handler: { action in
            if let textFields = self.createAlert.textFields,
               let name = textFields[0].text?.trimmingCharacters(in: .whitespacesAndNewlines),
               let date = textFields[1].text?.trimmingCharacters(in: .whitespacesAndNewlines),
               let start = textFields[2].text?.trimmingCharacters(in: .whitespacesAndNewlines),
               let end = textFields[3].text?.trimmingCharacters(in: .whitespacesAndNewlines),
               let location = textFields[4].text?.trimmingCharacters(in: .whitespacesAndNewlines),
               let hostedBy = textFields[5].text?.trimmingCharacters(in: .whitespacesAndNewlines),
               name != "", date != "", start != "", end != "", location != "" {

                let eventObject = Event(id: String(self.eventData.count + 1), name: name, location: location, date: date, start: start, end: end, hostedBy: hostedBy)

                self.eventData.append(eventObject)
                self.shownEventData = self.eventData
                self.eventTableView.reloadData()
            }
        }))
        
        
        if #available(iOS 10.0, *) {
            eventTableView.refreshControl = refreshControl
        } else {
            eventTableView.addSubview(refreshControl)
        }
//        eventTableView.refreshControl = refreshControl

        refreshControl.addTarget(self, action: #selector(refreshData), for: .valueChanged)
        
    }
    
    func setupConstraints() {
        // eventTableView constraints
        NSLayoutConstraint.activate([
            eventTableView.topAnchor.constraint(equalTo: view.topAnchor),
            eventTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            eventTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            eventTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
    }
    
    @objc func refreshData() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            self.shownEventData = self.eventData
            // should sort here
            self.eventTableView.reloadData()
            self.refreshControl.endRefreshing()
        }
    }
    
    // presents alert controller with all the text fields
    @objc func presentCreateAlert() {
        present(createAlert, animated: true)
    }

}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        currentIndexPathToUpdate = indexPath
        let eventInfoViewController = EventInfoViewController(eventObject: self.shownEventData[indexPath.row])
        present(eventInfoViewController, animated: true)
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shownEventData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: eventReuseIdentifier, for: indexPath) as! EventTableViewCell
        let eventObject = shownEventData[indexPath.row]
        cell.configure(with: eventObject)
        return cell
    }
}
