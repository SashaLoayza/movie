//
//  ViewController.swift
//  final_proj
//
//  Created by Kevin Arias on 5/1/22.
//

import UIKit

class ViewController: UIViewController {
    
    let eventTableView = UITableView()
    let eventReuseIdentifier = "eventReuseIdentifier"
    let refreshControl = UIRefreshControl()
    let addEventBtn = UIButton()
    let signOutBtn = UIBarButtonItem()
    let profileBtn = UIBarButtonItem()
    var currUser: User?
    
    // alert for adding event
    let createAlert = UIAlertController(title: "Add new event", message: nil, preferredStyle: .alert)
    
    // alert for signing out
    let signOutAlert = UIAlertController(title: "Sign out", message: nil, preferredStyle: .alert)
    
    var eventData: [Event] = []
    var shownEventData: [Event] = []
        
    var currentIndexPathToUpdate: IndexPath?
    
    // initialize to have user available to display information
    init(currUser: User?) {
        super.init(nibName: nil, bundle: nil)
        self.currUser = currUser
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationItem.hidesBackButton = true
        view.backgroundColor = .systemGray5
        self.navigationController?.navigationBar.barTintColor = UIColor.systemBlue
        self.navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
        title = "Upcoming Events"

        createDummyData() // WILL CHANGE THIS ONCE ROUTES CONFIGURED
        setupViews()
        setupConstraints()
        refreshData()
        
    }
    
    func createDummyData() {
        let event1 = Event(id: "1", name: "Movie", location: "Donlon", start: "04/22/22 08:02:45", end: "04/22/22 12:05:00")
        let event2 = Event(id: "2", name: "Movie: The Sequel", location: "Also Donlon", start: "08/23/22 23:03:45", end: "08/23/22 23:06:45")
        let events = [event1, event2]
        
//        NetworkManager.getAllEvents { events in
//            self.eventData = events
//            // should sort here, by what Idk yet
//            self.shownEventData = self.eventData
//            self.eventTableView.reloadData()
//        }
        self.eventData = events
        self.shownEventData = self.eventData
        self.eventTableView.reloadData()
    }
    
    func setupViews() {
        // eventTableView setup
        eventTableView.backgroundColor = .systemGray5
        eventTableView.delegate = self
        eventTableView.dataSource = self
        eventTableView.register(EventTableViewCell.self, forCellReuseIdentifier: eventReuseIdentifier)
        eventTableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(eventTableView)
        
        // addEventButton setup
        profileBtn.title = "Profile >"
        profileBtn.tintColor = .white
        profileBtn.target = self
        profileBtn.action = #selector(pushProfileViewController)
        navigationItem.rightBarButtonItem = profileBtn
        
        // addEventBtn setup
        addEventBtn.setTitle("Add Event", for: .normal)
        addEventBtn.titleLabel!.font = UIFont.systemFont(ofSize: 20)
        addEventBtn.layer.backgroundColor = UIColor.systemBlue.cgColor
        addEventBtn.layer.cornerRadius = 5
//        addEventBtn.addTarget(self, action: #selector(presentCreateAlert), for: .touchUpInside)
        addEventBtn.addTarget(self, action: #selector(pushEventAddViewController), for: .touchUpInside)
        addEventBtn.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(addEventBtn)
    
        // signOutBtn setup
        signOutBtn.title = "Sign out"
        signOutBtn.tintColor = .white
        signOutBtn.target = self
        signOutBtn.action = #selector(presentSignOutAlert)
        navigationItem.leftBarButtonItem = signOutBtn
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        // createAlert setup
        createAlert.addAction(cancelAction)
        
        // signOutAlert setup
        signOutAlert.addAction(UIAlertAction(title: "Confirm", style: .default) { _ in
            self.navigationController?.popViewController(animated: true)
        })
        signOutAlert.addAction(cancelAction)
        
//        let placeholderTexts = [
//            "Name of event",
//            "Date of event",
//            "Start time",
//            "End time",
//            "Location of event",
//            "Host of event (optional)"
//        ]
//
//        for placeholderText in placeholderTexts {
//            createAlert.addTextField(configurationHandler: { textField in
//                textField.placeholder = placeholderText
//            })
//        }
//
//        // this is a form to prompt user to add event upon clicking "Add Event" button
//        createAlert.addAction(UIAlertAction(title: "Add", style: .default, handler: { action in
//            if let textFields = self.createAlert.textFields,
//               let name = textFields[0].text?.trimmingCharacters(in: .whitespacesAndNewlines),
//               let start = textFields[1].text?.trimmingCharacters(in: .whitespacesAndNewlines),
//               let end = textFields[2].text?.trimmingCharacters(in: .whitespacesAndNewlines),
//               let location = textFields[3].text?.trimmingCharacters(in: .whitespacesAndNewlines),
//               let hosted_by = textFields[4].text?.trimmingCharacters(in: .whitespacesAndNewlines),
//               name != "", start != "", end != "", location != "" {
//                NetworkManager.createEvent(name: name, location: location, start: start, end: end, hosted_by: hosted_by) { event in
//
//                    self.eventData.append(event)
//                    self.shownEventData = self.eventData
//                    self.eventTableView.reloadData()
//                }
//            }
//        }))

        eventTableView.refreshControl = refreshControl

        refreshControl.addTarget(self, action: #selector(refreshData), for: .valueChanged)
    }
    
    func setupConstraints() {
        // addEventBtn constraints
        NSLayoutConstraint.activate([
            addEventBtn.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -30),
            addEventBtn.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 60),
            addEventBtn.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -60)
        ])
        
        // eventTableView constraints
        NSLayoutConstraint.activate([
            eventTableView.topAnchor.constraint(equalTo: view.topAnchor),
            eventTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            eventTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            eventTableView.bottomAnchor.constraint(equalTo: addEventBtn.topAnchor, constant: -30),
        ])
    }
    
    @objc func refreshData() {
        NetworkManager.getAllEvents { events in
            self.eventData = events
            self.shownEventData = self.eventData
            // should sort here
            self.eventTableView.reloadData()
            self.refreshControl.endRefreshing()
        }
    }
    
    // presents alert controller with all the text fields
    @objc func presentCreateAlert() {
        present(createAlert, animated: true)
    }
    
    // presents alert controller double-checking sign out
    @objc func presentSignOutAlert() {
        present(signOutAlert, animated: true)
    }
    
    // push profile controller
    @objc func pushProfileViewController() {
        let profileViewController = ProfileViewController(currUser: currUser)
        self.navigationController?.pushViewController(profileViewController, animated: true)
    }
    
    // push event add controller
    @objc func pushEventAddViewController() {
        let eventAddViewController = EventAddViewController()
        
        // adapted from https://stackoverflow.com/questions/31970617/push-up-view-controller-from-bottom-using-swift
        let pushTransition = CATransition()
        pushTransition.duration = 0.5
        pushTransition.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        pushTransition.type = CATransitionType.moveIn
        pushTransition.subtype = CATransitionSubtype.fromTop
        self.navigationController?.view.layer.add(pushTransition, forKey: nil)
        self.navigationController?.pushViewController(eventAddViewController, animated: false)
    }
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        currentIndexPathToUpdate = indexPath
        let eventInfoViewController = EventInfoViewController(eventObject: self.shownEventData[indexPath.row], currUser: currUser)
        present(eventInfoViewController, animated: true)
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shownEventData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: eventReuseIdentifier, for: indexPath) as! EventTableViewCell
        let eventObject = shownEventData[indexPath.row]
        cell.configure(with: eventObject)
        return cell
    }
}

// must allow EventAddViewController to update events and refresh them
protocol EventAddViewDelegate {
    func eventsUpdate(event: Event) -> Void
}

extension ViewController: EventAddViewDelegate {
    func eventsUpdate(event: Event) {
        self.eventData.append(event)
        self.shownEventData = self.eventData
        self.eventTableView.reloadData()
    }
}
