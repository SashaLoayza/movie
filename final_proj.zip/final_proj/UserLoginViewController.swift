//
//  UserLoginViewController.swift
//  final_proj
//
//  Created by Kevin Arias on 5/5/22.
//

import UIKit

class UserLoginViewController: UIViewController {
    
    var currUser: User?
    let introTextView = UITextView()
    let signinLabel = UILabel()
    let usernameField = UITextField()
    let passwordField = UITextField()
    let signInBtn = UIButton()
    let signUpBtn = UIButton()
    
    // invalidAccountAlert for invalid username/password
    let invalidAccountAlert = UIAlertController(title: "Invalid username or password", message: nil, preferredStyle: .alert)
    
    // createAccountAlert for adding account
    let createAccountAlert = UIAlertController(title: "Create account", message: nil, preferredStyle: .alert)

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        title = "Welcome!"
        self.navigationController?.navigationBar.barTintColor = UIColor.systemBlue
        self.navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
        view.backgroundColor = .systemGray5
        
        setupViews()
        setupConstraints()
    }
    
    func setupViews() {
        
        // introTextView setup
        introTextView.text = "Organize movie nights.\n\nAdd your voice to the Cornell Cinema Scene."
        introTextView.textColor = .black
        introTextView.backgroundColor = .systemGray5
        introTextView.textAlignment = .center
        introTextView.isEditable = false
        introTextView.font = UIFont.boldSystemFont(ofSize: 30)
        introTextView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(introTextView)

        // signinLabel setup
        signinLabel.text = "Sign in"
        signinLabel.font = UIFont.boldSystemFont(ofSize: 30)
        signinLabel.textColor = .systemBlue
        signinLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(signinLabel)

        // usernameField setup
        usernameField.placeholder = "Username"
        usernameField.font = UIFont.systemFont(ofSize: 20)
        usernameField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(usernameField)
        
        // passwordField setup
        passwordField.placeholder = "Password"
        passwordField.font = UIFont.systemFont(ofSize: 20)
        passwordField.isSecureTextEntry = true
        passwordField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(passwordField)
        
        // signinBtn setup
        signInBtn.setTitle("Enter", for: .normal)
        signInBtn.titleLabel!.font = UIFont.systemFont(ofSize: 20)
        signInBtn.layer.backgroundColor = UIColor.systemBlue.cgColor
        signInBtn.layer.cornerRadius = 5
        signInBtn.addTarget(self, action: #selector(signIn), for: .touchUpInside)
        signInBtn.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(signInBtn)
        
        // signupBtn setup
        signUpBtn.setTitle("Sign up", for: .normal)
        signUpBtn.titleLabel!.font = UIFont.systemFont(ofSize: 20)
        signUpBtn.layer.backgroundColor = UIColor.systemBlue.cgColor
        signUpBtn.layer.cornerRadius = 5
        signUpBtn.addTarget(self, action: #selector(signUp), for: .touchUpInside)
        signUpBtn.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(signUpBtn)
        
        // invalidAccountAlert setup
        invalidAccountAlert.addAction(UIAlertAction(title: "Try again", style: .cancel, handler: nil))
        
        // createAccountAlert setup
        createAccountAlert.addTextField { textField in
            textField.placeholder = "Enter username"
        }
        
        createAccountAlert.addTextField { textField in
            textField.placeholder = "Enter password"
            textField.isSecureTextEntry = true
        }
        
        createAccountAlert.addTextField { textField in
            textField.placeholder = "Enter your name"
        }
        
        createAccountAlert.addAction(UIAlertAction(title: "Create", style: .default, handler: { action in
            if let textFields = self.createAccountAlert.textFields,
               let username = textFields[0].text?.trimmingCharacters(in: .whitespacesAndNewlines),
               let password = textFields[1].text?.trimmingCharacters(in: .whitespacesAndNewlines),
               let name = textFields[2].text?.trimmingCharacters(in: .whitespacesAndNewlines),
               username != "", password != "", name != "" {
                NetworkManager.createUser(name: name, username: username, password: password) { user in
                    self.currUser = user
                }
            }
        }))
        
        createAccountAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
    }
    
    func setupConstraints() {
        let sidePadding: CGFloat = 30

        // introTextView constraints
        NSLayoutConstraint.activate([
            introTextView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 30),
            introTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: sidePadding),
            introTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -sidePadding),
            introTextView.bottomAnchor.constraint(equalTo: view.centerYAnchor, constant: -85)
        ])
        
        // signinLabel constraints
        NSLayoutConstraint.activate([
            signinLabel.topAnchor.constraint(equalTo: introTextView.bottomAnchor),
            signinLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: sidePadding),
            signinLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -sidePadding)
        ])
        
        // usernameField constraints
        NSLayoutConstraint.activate([
            usernameField.topAnchor.constraint(equalTo: signinLabel.bottomAnchor, constant: 15),
            usernameField.leadingAnchor.constraint(equalTo: signinLabel.leadingAnchor),
            usernameField.trailingAnchor.constraint(equalTo: signinLabel.trailingAnchor)
        ])
        
        // passwordField constraints
        NSLayoutConstraint.activate([
            passwordField.topAnchor.constraint(equalTo: usernameField.bottomAnchor, constant: 15),
            passwordField.leadingAnchor.constraint(equalTo: signinLabel.leadingAnchor),
            passwordField.trailingAnchor.constraint(equalTo: signinLabel.trailingAnchor)
        ])
        
        // signInBtn constraints
        NSLayoutConstraint.activate([
            signInBtn.topAnchor.constraint(equalTo: passwordField.bottomAnchor, constant: 15),
            signInBtn.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            signInBtn.leadingAnchor.constraint(equalTo: signinLabel.leadingAnchor, constant: sidePadding),
            signInBtn.trailingAnchor.constraint(equalTo: signinLabel.trailingAnchor, constant: -sidePadding)
        ])
        
        // signUpBtn constraints
        NSLayoutConstraint.activate([
            signUpBtn.topAnchor.constraint(equalTo: signInBtn.bottomAnchor, constant: 15),
            signUpBtn.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            signUpBtn.leadingAnchor.constraint(equalTo: signinLabel.leadingAnchor, constant: sidePadding),
            signUpBtn.trailingAnchor.constraint(equalTo: signinLabel.trailingAnchor, constant: -sidePadding)
        ])

    }
    
    @objc func signIn() {
        if let username = usernameField.text,
           let password = passwordField.text,
           username != "", password != "" {
            self.navigationController?.pushViewController(ViewController(currUser: self.currUser), animated: true)
//             NetworkManager.getUserByPassword(username: username, password: password) { user in
//                self.currUser = user
//                self.navigationController?.pushViewController(ViewController(currUser: self.currUser), animated: true)
             } else {
                present(invalidAccountAlert, animated: true, completion: nil)
             }
    }
    
    @objc func signUp() {
        present(createAccountAlert, animated: true, completion: nil)
    }
}
