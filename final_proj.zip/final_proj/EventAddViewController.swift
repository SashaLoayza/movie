//
//  EventAddViewController.swift
//  final_proj
//
//  Created by Kevin Arias on 5/6/22.
//

import UIKit

class EventAddViewController: UIViewController {
    
    var eventAddViewDelegate: EventAddViewDelegate?
    let eventNameField = UITextField()
    let startDateLabel = UILabel()
    let startDatePicker = UIDatePicker()
    let endDateLabel = UILabel()
    let endDatePicker = UIDatePicker()
    let eventLocationField = UITextField()
    let hostedByField = UITextField()
    let createBtn = UIButton()
    let cancelBtn = UIBarButtonItem()
    let formatter = DateFormatter()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        view.backgroundColor = .systemGray5
        title = "New Event"
        self.navigationController?.navigationBar.barTintColor = UIColor.systemBlue
        self.navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
        navigationItem.hidesBackButton = true
        
        setupViews()
        setupConstraints()
    }
    
    func setupViews() {
        let fontSize: CGFloat = 20
        // eventNameField setup
        eventNameField.placeholder = "Event name"
        eventNameField.textColor = .black
        eventNameField.textAlignment = .left
        eventNameField.font = UIFont.systemFont(ofSize: fontSize)
        eventNameField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(eventNameField)
        
        // startDateLabel setup
        startDateLabel.text = "Starts at: "
        startDateLabel.textAlignment = .left
        startDateLabel.textColor = .systemGray2
        startDateLabel.font = UIFont.systemFont(ofSize: fontSize)
        startDateLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(startDateLabel)
        
        // startDatePicker setup
        startDatePicker.preferredDatePickerStyle = .compact
        startDatePicker.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(startDatePicker)
        
        // endDateLabel setup
        endDateLabel.text = "Ends at: "
        endDateLabel.textAlignment = .left
        endDateLabel.textColor = .systemGray2
        endDateLabel.font = UIFont.systemFont(ofSize: fontSize)
        endDateLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(endDateLabel)
        
        // endDatePicker setup
        endDatePicker.preferredDatePickerStyle = .compact
        endDatePicker.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(endDatePicker)
        
        // eventLocationField setup
        eventLocationField.placeholder = "Event location"
        eventLocationField.textAlignment = .left
        eventLocationField.textColor = .black
        eventLocationField.font = UIFont.systemFont(ofSize: fontSize)
        eventLocationField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(eventLocationField)
        
        // hostedByField setup
        hostedByField.placeholder = "Organizer (optional)"
        hostedByField.textAlignment = .left
        hostedByField.textColor = .black
        hostedByField.font = UIFont.systemFont(ofSize: fontSize)
        hostedByField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(hostedByField)
        
        // createBtn setup
        createBtn.setTitle("Create", for: .normal)
        createBtn.titleLabel!.font = UIFont.systemFont(ofSize: 20)
        createBtn.layer.backgroundColor = UIColor.systemBlue.cgColor
        createBtn.layer.cornerRadius = 5
        createBtn.addTarget(self, action: #selector(popEventAddController), for: .touchUpInside)
        createBtn.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(createBtn)
        
        // cancelBtn setup
        cancelBtn.title = "Cancel"
        cancelBtn.tintColor = .white
        cancelBtn.target = self
        cancelBtn.action = #selector(popEventAddController)
        navigationItem.leftBarButtonItem = cancelBtn
        
        // formatter setup
        formatter.setLocalizedDateFormatFromTemplate("MM/dd/yyyy HH:mm:ss")
        
    }
    
    func setupConstraints() {
        let sidePadding: CGFloat = 30
        let vertPadding: CGFloat = 30

        // eventNameField constraints
        NSLayoutConstraint.activate([
            eventNameField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 60),
            eventNameField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: sidePadding),
            eventNameField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -sidePadding)
        ])

        // startDateLabel constraints
        NSLayoutConstraint.activate([
            startDateLabel.topAnchor.constraint(equalTo: eventNameField.bottomAnchor, constant: vertPadding),
            startDateLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: sidePadding),
            startDateLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -sidePadding)
        ])

        // startDatePicker constraints
        NSLayoutConstraint.activate([
            startDatePicker.topAnchor.constraint(equalTo: startDateLabel.bottomAnchor, constant: 15),
            startDatePicker.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: sidePadding),
//            startDatePicker.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -sidePadding)
        ])
        
        // endDateLabel constraints
        NSLayoutConstraint.activate([
            endDateLabel.topAnchor.constraint(equalTo: startDatePicker.bottomAnchor, constant: vertPadding),
            endDateLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: sidePadding),
            endDateLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -sidePadding)
        ])

        // endDatePicker constraints
        NSLayoutConstraint.activate([
            endDatePicker.topAnchor.constraint(equalTo: endDateLabel.bottomAnchor, constant: 15),
            endDatePicker.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: sidePadding),
//            endDatePicker.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -sidePadding)
        ])
        
        // eventLocationField constraints
        NSLayoutConstraint.activate([
            eventLocationField.topAnchor.constraint(equalTo: endDatePicker.bottomAnchor, constant: vertPadding),
            eventLocationField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: sidePadding),
            eventLocationField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -sidePadding)
        ])
        
        // hostedByField constraints
        NSLayoutConstraint.activate([
            hostedByField.topAnchor.constraint(equalTo: eventLocationField.bottomAnchor, constant: vertPadding),
            hostedByField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: sidePadding),
            hostedByField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -sidePadding)
        ])

        // createBtn constraints
        NSLayoutConstraint.activate([
            createBtn.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -30),
            createBtn.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 60),
            createBtn.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -60)
        ])
        
    }
    
    @objc func createEvent() {
        let start: String? = formatter.string(from: startDatePicker.date).trimmingCharacters(in: .whitespacesAndNewlines)
        let end: String? = formatter.string(from: endDatePicker.date).trimmingCharacters(in: .whitespacesAndNewlines)
        if let name = eventNameField.text?.trimmingCharacters(in: .whitespacesAndNewlines),
           let location = eventLocationField.text?.trimmingCharacters(in: .whitespacesAndNewlines),
           let hostedBy = hostedByField.text?.trimmingCharacters(in: .whitespacesAndNewlines),
           name != "", location != "" {
            NetworkManager.createEvent(name: name, location: location, start: start!, end: end!) { event in
                self.eventAddViewDelegate?.eventsUpdate(event: event)
                }
            }
    }
    
    @objc func popEventAddController() {
        // adapted from https://stackoverflow.com/questions/31970617/push-up-view-controller-from-bottom-using-swift
        let popTransition:CATransition = CATransition()
        popTransition.duration = 0.5
        popTransition.timingFunction = CAMediaTimingFunction(name:CAMediaTimingFunctionName.easeInEaseOut)
        popTransition.type = CATransitionType.reveal
        popTransition.subtype = CATransitionSubtype.fromBottom
        self.navigationController?.view.layer.add(popTransition, forKey: kCATransition)
        self.navigationController?.popViewController(animated: false)
    }

}
