//
//  EventTableViewCell.swift
//  final_proj
//
//  Created by Kevin Arias on 5/1/22.
//

import UIKit

class EventTableViewCell: UITableViewCell {

    let nameLabel = UILabel()
    let locationLabel = UILabel()
    let dateLabel = UILabel()
    let timeLabel = UILabel()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none

        setupViews()
        setupConstraints()
    }
    
    func setupViews() {
        let infoFontSize: CGFloat = 15

        // nameLabel setup
        nameLabel.textAlignment = .center
        nameLabel.font = UIFont.systemFont(ofSize: 20)
        nameLabel.textColor = .systemTeal
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(nameLabel)

        // locationLabel setup
        locationLabel.textAlignment = .left
        locationLabel.font = UIFont.systemFont(ofSize: infoFontSize)
        locationLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(locationLabel)
        
        // dateLabel setup
        dateLabel.textAlignment = .left
        dateLabel.font = UIFont.systemFont(ofSize: infoFontSize)
        dateLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(dateLabel)
        
        // timeLabel setup
        timeLabel.textAlignment = .right
        timeLabel.font = UIFont.systemFont(ofSize: infoFontSize)
        timeLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(timeLabel)
    }
    
    func setupConstraints() {
        let sidePadding: CGFloat = 15

        // nameLabel constraints
        NSLayoutConstraint.activate([
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 15),
            nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: sidePadding),
            nameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -sidePadding)
        ])

        // locationLabel constraints
        NSLayoutConstraint.activate([
            locationLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 10),
            locationLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: sidePadding),
            locationLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: sidePadding)
        ])
        
        // dateLabel constraints
        NSLayoutConstraint.activate([
            dateLabel.topAnchor.constraint(equalTo: locationLabel.bottomAnchor),
            dateLabel.leadingAnchor.constraint(equalTo: locationLabel.leadingAnchor),
            dateLabel.trailingAnchor.constraint(equalTo: contentView.centerXAnchor, constant: 15),
            dateLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -15)
        ])
        
        // timeLabel constraints
        NSLayoutConstraint.activate([
            timeLabel.topAnchor.constraint(equalTo: locationLabel.bottomAnchor),
            timeLabel.leadingAnchor.constraint(equalTo: dateLabel.trailingAnchor),
            timeLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -sidePadding),
            timeLabel.bottomAnchor.constraint(equalTo: dateLabel.bottomAnchor)
        ])
    }
    
    // function that ViewController uses as the delegate to configure a cell
    func configure(with eventObject: Event) {
        let defaultString = "N/A"
        nameLabel.text = eventObject.name
        locationLabel.text = "Where: \(eventObject.location ?? defaultString)"
        dateLabel.text = "When: \(eventObject.date ?? defaultString)"
        timeLabel.text = "\(eventObject.start ?? defaultString) - \(eventObject.end ?? defaultString)"
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

